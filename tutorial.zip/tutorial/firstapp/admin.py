from django.contrib import admin
from .models import Curriculum

admin.site.register(Curriculum)
